# GENERATED VERSION FILE
# TIME: Tue Aug  6 20:29:22 2019

__version__ = '0.6.0+unknown'
short_version = '0.6.0'
